const enabled = document.getElementById("enabled");

chrome.storage.local.get("enabled", state => {
  enabled.checked = state.enabled ?? true;
});

enabled.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: enabled.checked });
});

document.getElementById("refresh").addEventListener("click", async () => {
  await chrome.storage.local.set({ refreshToken: Date.now() });
  window.close();
});

checkUpdate();

async function checkUpdate() {
  const box = document.getElementById("version");
  const current = chrome.runtime.getManifest().version;
  try {
    const response = await fetch("https://bydtesla1609.github.io/Lijiahui1609.github.io/release.json", { cache: "no-store" });
    const release = await response.json();
    if (newerThan(release.version, current)) {
      box.replaceChildren(document.createTextNode(`发现新版 ${release.version} · `));
      const link = document.createElement("a");
      link.href = new URL(release.download, response.url).href;
      link.target = "_blank";
      link.textContent = "查看更新";
      box.append(link);
    } else {
      box.textContent = `已是最新版 · v${current}`;
    }
  } catch {
    box.textContent = `当前版本 · v${current}`;
  }
}

function newerThan(latest, current) {
  const a = String(latest).split(".").map(Number);
  const b = String(current).split(".").map(Number);
  return a.some((part, index) => part > (b[index] || 0) && a.slice(0, index).every((n, i) => n === (b[i] || 0)));
}
