const TOPICS = [
  topic("中医原理", "中医 原理 科普", "field", ["中医", "经络", "中药"]),
  topic("饮食健康", "饮食 健康 科普", "field", ["饮食健康", "营养学"]),
  topic("运动康复", "运动 康复 科普", "field", ["运动康复", "康复训练"]),
  topic("睡眠科学", "睡眠 科学 科普", "field", ["睡眠", "失眠"]),
  topic("中国宫廷建筑", "中国 宫廷 建筑", "field", ["宫廷建筑", "故宫建筑"]),
  topic("苏州园林", "苏州 园林 建筑", "field", ["苏州园林", "古典园林"]),
  topic("意式建筑", "意大利 建筑 风格", "field", ["意式建筑", "意大利建筑"]),
  topic("泰式宫殿", "泰国 宫殿 建筑", "field", ["泰式建筑", "泰国宫殿"]),
  topic("方言演变", "方言 演变 语言学", "field", ["方言", "语言演变"]),
  topic("行星地质", "行星 地质 科普", "field", ["行星地质", "地外地质"]),
  topic("法律案例", "法律 案例 深度", "field", ["法律案例", "判例"]),
  topic("农业技术", "现代 农业 技术", "field", ["农业技术", "现代农业"]),
  topic("外国人在中国吃美食", "外国人 中国 美食 体验", "culture", ["外国人吃中国", "外国人中国美食"]),
  topic("跨国家庭日常", "跨国家庭 日常 生活", "culture", ["跨国家庭", "跨国婚姻"]),
  topic("留学生看中国", "留学生 中国 生活 观察", "culture", ["留学生中国", "外国留学生"]),
  topic("海外华人日常", "海外华人 日常 生活", "culture", ["海外华人", "华侨生活"]),
  topic("外国人学中文", "外国人 学中文 日常", "culture", ["外国人学中文", "中文学习"]),
  topic("跨文化职场", "跨文化 职场 工作", "culture", ["跨文化职场", "海外工作"]),
  topic("国际友人逛中国", "外国人 逛中国 城市", "culture", ["外国人逛中国", "外国人游中国"]),
  topic("异国餐桌", "不同国家 家庭 做饭 日常", "culture", ["异国美食", "外国家庭做饭"]),
  topic("县城里的年轻人", "县城 年轻人 生活", "region", ["县城青年", "县城生活"]),
  topic("义乌外贸", "义乌 外贸 商人", "region", ["义乌", "外贸"]),
  topic("景德镇手艺人", "景德镇 手艺人 陶瓷", "region", ["景德镇", "陶瓷手艺"]),
  topic("东北工业往事", "东北 工业 历史", "region", ["东北工业", "老工业基地"]),
  topic("边境小城日常", "边境 小城 日常", "region", ["边境小城", "边境生活"]),
  topic("西北新行业", "西北 新产业 发展", "region", ["西北产业", "西北发展"]),
  topic("海岛上的职业", "海岛 职业 生活", "region", ["海岛职业", "海岛生活"]),
  topic("世界小城故事", "世界 小城 人物 故事", "region", ["世界小城", "小城故事"]),
  topic("趣味配音", "趣味 配音 知识", "style", ["趣味配音", "配音科普"]),
  topic("趣味科普", "趣味 科普", "style", ["趣味科普", "轻松科普"]),
  topic("清晰讲解", "通俗 清晰 讲解", "style", ["通俗讲解", "清晰讲解"]),
  topic("高校课堂", "大学 公开课 课堂", "style", ["高校课堂", "大学公开课"]),
  topic("会议讲座", "学术 会议 讲座", "style", ["会议讲座", "学术讲座"]),
  topic("动画解释", "动画 讲解 科普", "style", ["动画讲解", "动画科普"]),
  topic("实验演示", "实验 演示 科普", "style", ["实验演示", "科学实验"]),
  topic("人物访谈", "人物 深度 访谈", "style", ["人物访谈", "深度访谈"]),
  topic("田野纪录", "田野 调查 纪录片", "style", ["田野调查", "田野纪录"]),
  topic("城市排水系统", "城市 排水 系统 科普", "field", ["城市排水", "下水道"]),
  topic("博物馆修复", "博物馆 文物 修复", "field", ["文物修复", "博物馆修复"]),
  topic("食品工业", "食品 工厂 生产线", "field", ["食品工业", "食品工厂"]),
  topic("认知偏差", "认知偏差 心理学", "field", ["认知偏差", "思维误区"]),
  topic("气味科学", "气味 嗅觉 科学", "field", ["气味科学", "嗅觉"]),
  topic("声音设计", "电影 游戏 声音设计", "field", ["声音设计", "拟音"]),
  topic("供应链幕后", "供应链 物流 幕后", "field", ["供应链", "物流系统"]),
  topic("海洋考古", "水下 海洋 考古", "field", ["海洋考古", "水下考古"]),
  topic("灾害救援", "灾害 救援 纪实", "field", ["灾害救援", "应急救援"]),
  topic("颜色的历史", "颜色 颜料 历史", "field", ["颜色史", "颜料历史"]),
  topic("移民家庭的两代人", "移民 家庭 两代人 生活", "culture", ["移民家庭", "移民二代"]),
  topic("同一道菜的不同做法", "不同国家 同一道菜 做法", "culture", ["各国做法", "不同国家美食"]),
  topic("跨文化误会", "跨文化 误会 日常", "culture", ["跨文化误会", "文化差异"]),
  topic("国际学校里的日常", "国际学校 学生 日常", "culture", ["国际学校", "多元文化校园"]),
  topic("翻译者的工作现场", "翻译 口译 工作 现场", "culture", ["口译现场", "翻译工作"]),
  topic("不同国家的养老", "不同国家 老人 养老 生活", "culture", ["国外养老", "老人生活"]),
  topic("外国创作者的一天", "外国博主 一天 日常 vlog", "culture", ["外国博主", "海外博主"]),
  topic("交换生的普通周末", "交换生 周末 vlog", "culture", ["交换生", "留学周末"]),
  topic("跨国同事一起工作", "外国同事 中国同事 工作 日常", "culture", ["外国同事", "跨国团队"]),
  topic("外国朋友第一次体验", "外国朋友 第一次 体验 中国", "culture", ["外国朋友体验", "外国人第一次"]),
  topic("海外街头的普通一天", "海外 街头 日常 vlog", "culture", ["海外街头", "国外日常"]),
  topic("不同文化一起完成一件事", "中外 合作 挑战 日常", "culture", ["中外合作", "外国朋友合作"]),
  topic("外国人的家乡日常", "外国博主 家乡 生活 vlog", "culture", ["外国人家乡", "海外家乡生活"]),
  topic("多文化室友生活", "外国室友 合租 日常", "culture", ["外国室友", "跨文化合租"]),
  topic("跨国情侣的普通一天", "跨国情侣 一天 vlog", "culture", ["跨国情侣", "异国情侣"]),
  topic("海外市场与小店", "国外 市场 小店 摊主 日常", "culture", ["国外市场", "海外小店"]),
  topic("口岸的一天", "口岸 工作 一天 纪实", "region", ["口岸", "边检工作"]),
  topic("资源型城市转型", "资源型城市 转型 产业", "region", ["资源型城市", "城市转型"]),
  topic("港口背后的产业", "港口 产业 物流 纪实", "region", ["港口产业", "港口物流"]),
  topic("高原上的新生活", "高原 生活 产业 纪录片", "region", ["高原生活", "高原产业"]),
  topic("老街区更新", "老街区 城市更新 居民", "region", ["老街区", "城市更新"]),
  topic("一条河流沿岸", "河流 沿岸 城市 人物", "region", ["沿岸城市", "河流故事"]),
  topic("凌晨工作的城市", "城市 凌晨 职业 工作", "region", ["凌晨工作", "夜间职业"]),
  topic("岛屿学校的一天", "海岛 学校 学生 日常", "region", ["海岛学校", "岛上学生"]),
  topic("山谷里的小产业", "山区 产业 工厂 村庄", "region", ["山区产业", "山村工厂"]),
  topic("铁路终点的小城", "铁路 终点 小城 生活", "region", ["铁路小城", "火车终点站"]),
  topic("气候塑造的生活", "气候 地区 居民 生活", "region", ["气候生活", "极端气候居民"]),
  topic("一座城的菜市场", "城市 菜市场 摊主 纪录片", "region", ["城市菜市场", "市场摊主"]),
  topic("国境线两边的日常", "边境 两国 居民 日常", "region", ["边境居民", "国境生活"]),
  topic("产业迁移中的城市", "产业迁移 城市 工人", "region", ["产业迁移", "城市工人"]),
  topic("无旁白观察", "无旁白 观察 纪录片", "style", ["无旁白", "观察纪录片"]),
  topic("第一人称体验", "第一人称 体验 纪实", "style", ["第一人称", "沉浸体验"]),
  topic("数据可视化讲解", "数据 可视化 讲解", "style", ["数据可视化", "图表讲解"]),
  topic("完整制作过程", "从零 制作 全过程", "style", ["制作全过程", "从零制作"]),
  topic("口述历史", "口述历史 人物 访谈", "style", ["口述历史", "历史访谈"]),
  topic("观点辩论", "观点 辩论 深度", "style", ["观点辩论", "公开辩论"]),
  topic("失败复盘", "失败 项目 复盘", "style", ["失败复盘", "项目复盘"]),
  topic("微观慢镜头", "显微镜 慢镜头 科普", "style", ["显微镜", "慢镜头科普"]),
  topic("声音带你看现场", "环境声音 无旁白 纪录", "style", ["环境声音", "无旁白纪录"]),
  topic("一件物品的完整旅程", "物品 制作 运输 使用 全过程", "style", ["完整旅程", "全生命周期"]),
  topic("地图叙事", "地图 动画 历史 地理 讲解", "style", ["地图动画", "地图叙事"]),
  topic("档案逐页解读", "档案 原始资料 解读", "style", ["档案解读", "原始资料"]),
  topic("跟拍一个工作日", "职业 跟拍 一天 纪录片", "style", ["职业跟拍", "工作日纪录"]),
  topic("同一问题多人回答", "街头采访 同一问题", "style", ["多人回答", "街头采访"]),
  topic("反直觉实验", "反直觉 实验 验证", "style", ["反直觉实验", "实验验证"]),
  topic("物件视角的历史", "物品 历史 文化 讲解", "style", ["物件历史", "器物故事"]),
  topic("修复与复原过程", "修复 复原 全过程", "style", ["修复过程", "复原过程"]),
  topic("一天的数据日记", "数据记录 一天 可视化", "style", ["数据日记", "生活数据"])
];

const CREATOR_SEEDS = [
  "原创 动画 短片", "深度 旅行 纪录片", "科学 实验 手工",
  "城市 观察 纪录片", "历史 档案 人文", "自然 生态 摄影",
  "冷门 职业 记录", "独立 音乐 原创", "文物 修复 记录",
  "工业 制造 纪录片", "乡村 创业 纪实", "口述历史 访谈",
  "海洋 生物 摄影", "数据 可视化 科普", "传统 手艺 记录"
];

const BLOCKED_CONTENT = /AV女优|女优|成人视频|色情|福利视频|福利姬|擦边|性感|内衣|巨乳|黑丝|白丝|足控|偷拍|走光|性冲动|两性教育|性教育|私房写真|AI美女|AI视频/i;
const GENERIC_TERMS = new Set(["中国", "不同", "日常", "生活", "视频", "科普", "纪录片", "记录", "观察", "体验", "人物", "故事", "工作", "讲解", "深度", "内容", "现场", "一个", "一种", "第一次"]);

function topic(name, query, kind, aliases) {
  return { name, query, kind, aliases };
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["enabled", "exposure"], ({ enabled, exposure }) => {
    chrome.storage.local.set({
      enabled: enabled ?? true,
      exposure: exposure ?? {}
    });
  });
});

chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  if (message.type === "getFeed") {
    buildFeed().then(reply);
    return true;
  }
  if (message.type === "recordExposure") {
    recordExposure(message.text, message.author).then(() => reply({ ok: true }));
    return true;
  }
});

async function recordExposure(text = "", author = "") {
  const { exposure = {}, seenAuthors = [] } = await chrome.storage.local.get(["exposure", "seenAuthors"]);
  const normalized = text.toLowerCase();
  for (const topic of TOPICS) {
    if (topic.aliases.some(alias => normalized.includes(alias.toLowerCase()))) {
      exposure[topic.name] = (exposure[topic.name] || 0) + 1;
    }
  }
  const authors = new Set(seenAuthors);
  if (author) authors.add(author.trim());
  await chrome.storage.local.set({ exposure, seenAuthors: [...authors].slice(-500) });
}

async function buildFeed() {
  const { exposure = {}, seenAuthors = [], refreshToken = 0 } = await chrome.storage.local.get(["exposure", "seenAuthors", "refreshToken"]);
  const kinds = ["field", "culture", "region", "style"];
  const dimensionGroups = [];
  for (const [index, kind] of kinds.entries()) {
    dimensionGroups.push(await buildDimensionGroup(kind, exposure, refreshToken + index));
  }
  const creator = await buildIndependentCreatorGroup(seenAuthors, refreshToken);
  const groups = makeGroupsIndependent([
    dimensionGroups[0], dimensionGroups[1], dimensionGroups[2], creator, dimensionGroups[3]
  ]);

  return {
    groups,
    fallbackTopics: groups.map(group => ({ name: group.topic, query: group.query }))
  };
}

async function buildDimensionGroup(kind, exposure, seed) {
  const candidates = TOPICS.filter(item => item.kind === kind)
    .map(item => ({ ...item, count: exposure[item.name] || 0, tie: Math.random() }))
    .sort((a, b) => a.count - b.count || a.tie - b.tie);
  for (const topic of candidates.slice(0, 6)) {
    try {
      const videos = await fetchTopic(topic, false);
      if (videos.length) return { topic: topic.name, query: topic.query, reason: reasonFor(topic, seed), videos };
    } catch {}
  }
  const topic = candidates[0];
  const videos = await fetchPopular(1 + Math.abs(Number(seed) || 0) % 5);
  return {
    topic: topic.name,
    query: topic.query,
    reason: videos.length ? `意外岔路：全站热门中的陌生内容` : reasonFor(topic, seed),
    detail: videos.length ? `“${topic.name}”暂时受限，已自动切换备用路线` : "正在恢复内容",
    videos
  };
}

function reasonFor(topic, seed) {
  const byKind = {
    field: ["细分领域盲区", "知识地图的一块空白", "未曾深入的角落"],
    culture: ["不同文化中的日常", "跨文化的新鲜视角", "另一种生活经验"],
    region: ["发生在不同地区的人和事", "地图之外的日常", "换个地方看世界"],
    style: ["换一种视频表达", "不一样的讲述方式", "尝试新的内容风格"]
  };
  const choices = byKind[topic.kind];
  return `${choices[Math.abs(Number(seed) || 0) % choices.length]}：${topic.name}`;
}

async function buildIndependentCreatorGroup(seenAuthors, seed) {
  const start = Math.abs(Number(seed) || 0) % CREATOR_SEEDS.length;
  const queries = [...CREATOR_SEEDS.slice(start), ...CREATOR_SEEDS.slice(0, start)].slice(0, 4);
  const candidates = [];
  for (const query of queries) {
    try { candidates.push(...await fetchTopic({ query }, false)); } catch {}
  }
  if (!candidates.length) candidates.push(...await fetchPopular(6));
  const authors = new Map();
  for (const video of candidates) {
    if (!video.author || !video.mid || seenAuthors.includes(video.author)) continue;
    const entry = authors.get(video.mid) || { mid: video.mid, author: video.author, videos: [], peak: 0, total: 0 };
    entry.videos.push(video);
    entry.peak = Math.max(entry.peak, numericViews(video.views));
    entry.total += numericViews(video.views);
    authors.set(video.mid, entry);
  }
  const best = [...authors.values()].sort((a, b) => creatorScore(b) - creatorScore(a))[0];
  if (!best) return { topic: "陌生创作者", query: queries[0], reason: "没看过的UP主：正在寻找", videos: [] };
  let videos = best.videos;
  try {
    const extra = await fetchCreator(best);
    if (extra.length) videos = extra;
  } catch {}
  return {
    topic: best.author,
    query: best.author,
    reason: `没看过的UP主：${best.author}`,
    detail: `候选作品最高 ${formatCompact(best.peak)} 播放`,
    videos: uniqueVideos(videos).sort((a, b) => numericViews(b.views) - numericViews(a.views)).slice(0, 6)
  };
}

function makeGroupsIndependent(groups) {
  const usedVideos = new Set();
  const usedAuthors = new Set();
  const order = [3, 0, 1, 2, 4];
  const independent = [];
  order.forEach(index => {
    const group = groups[index];
    const videos = group.videos.filter(video => !usedVideos.has(video.bvid) && !usedAuthors.has(String(video.mid))).slice(0, 6);
    videos.forEach(video => {
      usedVideos.add(video.bvid);
      if (video.mid) usedAuthors.add(String(video.mid));
    });
    independent[index] = { ...group, videos };
  });
  return independent;
}

async function fetchCreator(creator) {
  const topic = { query: creator.author };
  return (await fetchTopic(topic, false)).filter(video => String(video.mid) === String(creator.mid));
}

function creatorScore(author) {
  return Math.log1p(author.peak) * 2 + Math.log1p(author.total) + Math.min(author.videos.length, 4);
}

function numericViews(value) {
  const number = Number(String(value).replace(/[^\d.]/g, ""));
  return Number.isFinite(number) ? number : 0;
}

function formatCompact(value) {
  return value >= 10000 ? `${(value / 10000).toFixed(1)}万` : String(value || 0);
}

function uniqueVideos(videos) {
  return [...new Map(videos.map(video => [video.bvid, video])).values()];
}

async function fetchTopic(topic, allowPopular = true) {
  const shorter = topic.query.split(/\s+/).slice(0, 2).join(" ");
  const attempts = [
    { keyword: topic.query, order: "click", page: 1 + Math.floor(Math.random() * 3) },
    { keyword: topic.query, order: "pubdate", page: 1 },
    { keyword: shorter, order: "click", page: 1 },
    { keyword: shorter, order: "dm", page: 1 }
  ];
  let found = [];
  for (const attempt of attempts) {
    try {
      found = uniqueVideos([...found, ...await fetchSearch(attempt, topic)]);
      if (found.length >= 6) return found.slice(0, 12);
    } catch {}
  }
  return found.length ? found : allowPopular ? fetchPopular() : [];
}

async function fetchSearch(attempt, topic) {
  const url = new URL("https://api.bilibili.com/x/web-interface/search/all/v2");
  url.search = new URLSearchParams({ ...attempt, page: String(attempt.page) });
  const json = await fetchJson(url);
  const result = json.data?.result?.find(section => section.result_type === "video")?.data;
  if (json.code !== 0 || !Array.isArray(result)) return [];
  return result.map(item => ({
    bvid: item.bvid,
    title: stripHtml(item.title),
    author: item.author,
    cover: normalizeCover(item.pic),
    duration: item.duration,
    views: item.play,
    mid: item.mid,
    published: Number(item.pubdate) || 0
  })).filter(item => item.bvid && item.title && item.cover && isSafeVideo(item))
    .map(item => ({ item, score: relevanceScore(item, topic) }))
    .filter(entry => entry.score > 0)
    .sort((a, b) => b.score - a.score || numericViews(b.item.views) - numericViews(a.item.views))
    .map(entry => entry.item);
}

async function fetchPopular(page = 1 + Math.floor(Math.random() * 5)) {
  try {
    const url = `https://api.bilibili.com/x/web-interface/popular?ps=50&pn=${page}`;
    const json = await fetchJson(url);
    if (json.code !== 0 || !Array.isArray(json.data?.list)) return [];
    return shuffle(json.data.list.map(item => ({
      bvid: item.bvid,
      title: item.title,
      author: item.owner?.name,
      cover: normalizeCover(item.pic),
      duration: formatDuration(item.duration),
      views: item.stat?.view,
      mid: item.owner?.mid,
      published: Number(item.pubdate) || 0
    })).filter(item => item.bvid && item.title && item.cover && isSafeVideo(item))).slice(0, 12);
  } catch { return []; }
}

function isSafeVideo(video) {
  return !BLOCKED_CONTENT.test(`${video.title} ${video.author || ""}`);
}

function relevanceScore(video, topic) {
  if (!topic?.query) return 1;
  const text = `${video.title} ${video.author || ""}`.toLowerCase();
  const terms = [topic.name, ...(topic.aliases || []), ...topic.query.split(/\s+/)]
    .filter(term => term && term.length > 1 && !GENERIC_TERMS.has(term));
  return [...new Set(terms)].reduce((score, term) => score + (text.includes(term.toLowerCase()) ? (term.length >= 4 ? 4 : 2) : 0), 0);
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    const response = await fetch(url, { credentials: "include", signal: controller.signal });
    if (!response.ok) throw new Error(`B站接口返回 ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}

function formatDuration(seconds) {
  const value = Number(seconds) || 0;
  const minutes = Math.floor(value / 60);
  return `${minutes}:${String(value % 60).padStart(2, "0")}`;
}

function stripHtml(value = "") {
  return value.replace(/<[^>]*>/g, "").replaceAll("&quot;", "\"").replaceAll("&amp;", "&");
}

function normalizeCover(url = "") {
  return url.startsWith("//") ? `https:${url}` : url;
}

function shuffle(items) {
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}
