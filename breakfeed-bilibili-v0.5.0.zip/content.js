const PANEL_ID = "breakfeed-panel";
let lastVideoUrl = "";

start();

async function start() {
  const { enabled = true } = await chrome.storage.local.get("enabled");
  if (isHome()) updateHome(enabled);
  observeNavigation();
  recordVideoExposure();
}

chrome.storage.onChanged.addListener(changes => {
  if (changes.enabled && isHome()) updateHome(changes.enabled.newValue);
  if (changes.refreshToken && isHome()) renderFeed();
});

function isHome() {
  return location.hostname === "www.bilibili.com" && location.pathname === "/";
}

function updateHome(enabled) {
  document.documentElement.classList.toggle("breakfeed-enabled", Boolean(enabled));
  if (enabled) renderFeed();
  else document.getElementById(PANEL_ID)?.remove();
}

async function renderFeed() {
  document.getElementById(PANEL_ID)?.remove();
  const panel = element("section", { id: PANEL_ID });
  const header = element("div", { className: "breakfeed-header" });
  header.append(
    element("div", {}, element("strong", { textContent: "破茧探索" }), element("span", { textContent: "  来自你较少接触的领域" })),
    button("换一批", async () => {
      header.querySelector("button").disabled = true;
      await chrome.storage.local.set({ refreshToken: Date.now() });
    })
  );
  panel.append(header, element("div", { className: "breakfeed-status", textContent: "正在寻找陌生领域…" }));
  placePanel(panel);

  try {
    const feed = await chrome.runtime.sendMessage({ type: "getFeed" });
    panel.querySelector(".breakfeed-status")?.remove();
    if (feed?.groups?.length) {
      feed.groups.forEach(group => panel.append(videoGroup(group)));
    } else {
      panel.append(fallback(feed?.fallbackTopics || []));
    }
  } catch (error) {
    panel.querySelector(".breakfeed-status").textContent = "内容获取失败，请稍后刷新；原B站首页未受影响。";
    document.documentElement.classList.remove("breakfeed-enabled");
  }
}

function placePanel(panel) {
  const nativeFeed = document.querySelector(".recommended-container_floor-aside, .bili-feed4-layout");
  if (nativeFeed?.parentNode) nativeFeed.parentNode.insertBefore(panel, nativeFeed);
  else (document.querySelector("main") || document.body).append(panel);
}

function videoGroup(group) {
  const section = element("section", { className: "breakfeed-group" });
  section.append(element("div", { className: "breakfeed-group-title" },
    element("h2", { textContent: group.reason }),
    element("span", { textContent: group.detail || `${group.videos.length} 个选择` })
  ));
  const grid = element("div", { className: "breakfeed-grid" });
  group.videos.forEach(video => grid.append(videoCard(video)));
  if (group.videos.length) section.append(grid);
  else section.append(element("a", {
    className: "breakfeed-group-empty",
    href: `https://search.bilibili.com/all?keyword=${encodeURIComponent(group.query || group.topic)}`,
    textContent: "这一栏暂时没有加载成功，点击去B站继续探索 →"
  }));
  return section;
}

function videoCard(video) {
  const link = element("a", {
    className: "breakfeed-card",
    href: `https://www.bilibili.com/video/${video.bvid}`,
    target: "_self"
  });
  const image = element("img", { src: video.cover, alt: "", loading: "lazy", referrerPolicy: "no-referrer" });
  link.append(
    element("div", { className: "breakfeed-cover" }, image, element("span", { textContent: video.duration || "" })),
    element("h3", { textContent: video.title }),
    element("p", { textContent: `${video.author || "B站UP主"} · ${formatViews(video.views)}` }),
    element("p", { className: "breakfeed-tags", textContent: (video.tags || []).slice(0, 2).join(" · ") })
  );
  return link;
}

function fallback(topics) {
  const box = element("div", { className: "breakfeed-fallback" },
    element("p", { textContent: "B站暂时限制了内容读取。仍可从这些低接触领域开始探索：" })
  );
  topics.forEach(topic => box.append(element("a", {
    href: `https://search.bilibili.com/all?keyword=${encodeURIComponent(topic.query)}`,
    textContent: topic.name
  })));
  return box;
}

function recordVideoExposure() {
  if (!location.pathname.startsWith("/video/") || location.href === lastVideoUrl) return;
  lastVideoUrl = location.href;
  setTimeout(() => {
    const meta = document.querySelector('meta[name="keywords"]')?.content || "";
    const author = document.querySelector('meta[name="author"]')?.content
      || document.querySelector(".up-name")?.textContent || "";
    const title = document.title || "";
    chrome.runtime.sendMessage({ type: "recordExposure", text: `${title} ${meta}`, tags: meta, author });
  }, 2500);
}

function observeNavigation() {
  let previous = location.href;
  new MutationObserver(() => {
    if (location.href === previous) return;
    previous = location.href;
    setTimeout(() => {
      if (isHome()) chrome.storage.local.get("enabled", ({ enabled = true }) => updateHome(enabled));
      else document.documentElement.classList.remove("breakfeed-enabled");
      recordVideoExposure();
    }, 500);
  }).observe(document.documentElement, { childList: true, subtree: true });
}

function element(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  Object.assign(node, props);
  node.append(...children);
  return node;
}

function button(label, handler) {
  const node = element("button", { type: "button", textContent: label });
  node.addEventListener("click", handler);
  return node;
}

function formatViews(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "探索内容";
  return number >= 10000 ? `${(number / 10000).toFixed(1)}万播放` : `${number}播放`;
}
